/****************************************************************************
* Assignment5
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually or electronically from any othersource * (including web sites) or distributed to other students.
* Name: Nathan Kenopic  StudentID: 100083203  Date: April 9th, 2021
****************************************************************************/

var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(slide) {
  var i;
  var slides = document.getElementsByClassName("mySlides");

  if (slide > slides.length) {
    slideIndex = 1
  }

  if (slide < 1) {
    slideIndex = slides.length
  }

  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }

  slides[slideIndex-1].style.display = "block";
}

function translateFrench() {
  document.getElementById("headReview").innerHTML = "Avis clients anonymes";
  document.getElementById("reviews").innerHTML = "Le modèle Signature CX-5 offre d'excellentes performances de turbo et une excellente accélération, ainsi qu'un régulateur de vitesse intelligent qui démarre et s'arrête automatiquement aux feux de signalisation, avec une reconnaissance de signe même et des caméras à 360 degrés pour voir tout autour de la voiture pour se garer et passer. Apple Play me permet de jouer mes 2500 chansons sans problème et il sait quand me connecter automatiquement lorsque j'entre dans la cabine. Le système audio bascule. Le siège du conducteur s'ajuste vers le haut, le bas, l'arrière, l'avant, avec lombaire et plusieurs préréglages. Sur la route, la voiture est silencieuse et les virages super! Jusqu'à présent, je n'ai que des éloges pour mon CX-5 Signature! J'ai obtenu de l'argent pour le fait que ma dernière voiture argentée (une PT Turbo 2003) n'avait pas été endommagée après 15 ans de stationnement! Je ne pourrais pas être plus satisfait de l'apparence et des performances jusqu'à présent. La consommation d'essence n'est pas super alors que la plupart de ma conduite se fait juste en ville, mais je prévois un voyage sur l'autoroute de Los Angeles à San Francisco pour voir quel type de kilométrage il peut avoir sur la route ouverte, tandis qu'avec la puissance Turbo, nous pouvons toujours le faire fonctionner régulièrement. ou utilisez premium pour encore plus de puissance en mode Sport. La manipulation est géniale! Le volant est réglable et extensible. L'intérieur de ma voiture est raffiné avec des accents de bois, un accès USB, et j'apprends toujours toutes les cloches et sifflets, y compris l'entrée sans clé, avec plusieurs réglages de réglage du siège du conducteur. Ce Mazda CX-5 Signature 2020 est le meilleur VUS que j'ai jamais possédé. Je ne travaille pas pour Mazda, mais je suis un gestionnaire de terrain des télécommunications à la retraite qui a passé 40 ans sur la route à travers les États-Unis. Cette voiture est luxueuse! C'est un investissement à long terme car ma récompense pour avoir économisé si longtemps pour une nouvelle voiture. J'en ai acheté une à ma femme aussi! Jusqu'à présent, le service a également été excellent! <br><br> Je suis propriétaire de la Mazda 3 HB GT 2017 depuis quelques années maintenant. C'était une voiture géniale à conduire et super fiable et l'une des rares voitures à produire encore un manuel (jamais possédé d'automatique). Après avoir obtenu le manuel Premium 2020, je ne pourrais jamais revenir en arrière. Chaque pièce de cette voiture est une mise à niveau du 2017 que j'ai déjà adorée. Le style est presque nul et l'intérieur ressemble littéralement à un véhicule haut de gamme de premier ordre. Changement de vitesse sans effort et plus amusant que jamais. Le système de divertissement et le système audio Bose sont de premier ordre. Le Carplay est génial et la qualité sonore est super nette avec de superbes basses. Les caractéristiques de sécurité sont également excellentes et rendent la conduite sans effort et essentiellement sans souci. Il y a moins d'espace sur les sièges arrière pour des passagers supplémentaires, mais honnêtement, ce n'est pas un problème pour moi car j'ai rarement plus d'un passager dans ma voiture. Et avec les sièges arrière baissés, je peux toujours monter très facilement mon vélo de route et mes clubs de golf en cas de besoin. Les marges sont faibles sur Mazdas pour une raison, ils offrent des fonctionnalités et un style de premier ordre pour une fraction du prix que vous paieriez pour d'autres marques de voitures. <br><br> Je ne peux pas imaginer jamais échanger ou vendre cela. Il semble que chaque nouvelle voiture suit les mauvaises tendances de la particularité (c'est-à-dire: chaque commande de conduite contrôlée par un infodivertissement à écran tactile glitchy), mais la Mazda 3 va dans la meilleure direction possible. La quantité d'ingénierie, de réflexion et d'attention aux détails dans ce véhicule est incroyable. L'infodivertissement est rapide et vous ne devez pas trop détourner les yeux de la route. Votre bras repose exactement là où se trouve le bouton de commande - vous n'avez donc pas à regarder presque du tout l'écran - une fois que vous vous êtes habitué à la disposition de l'interface utilisateur. La maniabilité de cette voiture est supérieure à celle de toutes les voitures que j'ai conduites - et la traction intégrale est un bonus supplémentaire. Cependant, parfois, vous pouvez vraiment ressentir le poids supplémentaire du système AWD. Si la vitesse 0-60 est un problème, le FWD se sentira un peu plus rapide. Le mode manuel est très réactif et amusant à utiliser. Dans l'ensemble, il y a très peu de choses sur cette voiture que je n'aime pas. Les sièges à l'arrière sont un peu exigus pour les passagers de grande taille, c'est donc quelque chose à considérer si cela s'applique à votre style de vie. Je n'ai pas eu de problème avec l'espace de chargement car les sièges se replient presque à plat - cependant je n'ai pas d'enfants et n'ai généralement que 2 à 3 personnes dans la voiture à la fois. Dans l'ensemble, j'achèterais à nouveau cette voiture en un clin d'œil. <br> PS: Mazda, veuillez apporter le volant chauffant aux versions américaines. Nous aimons aussi que nos mains soient chaudes.";
}

function translateEnglish() {
  document.getElementById("headReview").innerHTML = "Anonymous Customer Reviews";
  document.getElementById("reviews").innerHTML = "The Signature model CX-5 has excellent turbo performance and acceleration, and intelligent cruise control that start and stop automatically at stoplights, with sign recognition even and 360 degree cameras to view all around the car for parking and passing. Apple play allows me to play my 2500 songs with no problems and it knows when to auto-connect when I enter the cabin. The sound system rocks. The driver's seat adjusts up, down, back, forward, with lumbar and multiple pre-sets. On the road, the car is quiet and corners great! I have nothing but praise for my CX-5 Signature so far! I got silver for the fact that my last silver car (a 2003 PT Turbo) had no parking lot damage after 15 years of parking lots! I couldn't be more pleased with the looks and performance so far. Gas mileage is not super while most of my driving is just around town but I plan a freeway trip from L.A. to San Francisco to see what kind of mileage it can have on the open road, while with Turbo power we can still run it on regular or use premium for even more horsepower in Sport mode. Handling is great! The steering wheel is adjustable and extendable. The interior of my car is refined with wood accents, USB access, and I am still learning all the bells and whistles, including keyless entry, with multiple driver seat adjustment settings. This 2020 Mazda  CX-5 Signature is the best SUV I have ever owned. I do not work for Mazda, but am a retired telecom field manager who spent 40 years on the road across the US. This car is luxurious! It is a long term investment as my reward for saving so long for a new car. I bought my wife one, too! So far service has been great, too! <br><br> I owned the 2017 Mazda 3 HB GT for a couple years now. Was an awesome car to drive and super reliable and one of the few cars still producing a manual (never owned an automatic). After getting the 2020 Premium manual, I could never go back. Every single part of this car is an upgrade from the 2017 which I already loved. The styling is next to none and the inside literally looks like a premier high end vehicle. Switching gears if effortless and more fun than ever. The entertainment system and Bose sound system are top notch. The Carplay is awesome and the sound quality is super crisp with great bass. The safety features are great too and make driving effortless and essentially worry free. There is less space in the back seats for additional passengers but honestly that is not an issue for me because I rarely have more than one passenger in my car. And the with the backseats down I can still very easily fit my road bike and golf clubs when needed. The margins are low on Mazdas for a reason, they offer top notch features and styling for a fraction of the price you'd pay for other car brands. <br><br> I can not imagine ever trading this in or selling it. It seems like every new car is following particularity bad trends (ie: every driving command controlled by a glitchy touch screen infotainment), but the Mazda 3 is going in the best possible direction. The amount of engineering, thought, and attention to detail in this vehicle is incredible. The infotainment is fast and you don't have to avert your eyes much from the road. Your arm rests right where the control knob is- so you don't have to look at the screen almost at all - once you get used to the UI layout. The handling on this car is superior to any car I've driven - and the AWD is an added bonus. Though, sometimes you can really feel the extra weight of the AWD system. If 0-60 speed is a concern, the FWD will feel quite a bit faster. The manual mode is very responsive and fun to use. Overall, there is very little about this car that I do not love. The seating in the back is a little cramped for tall passengers, so that is something to consider if that is applicable to your lifestyle. I have not had an issue with cargo space because the seats fold down almost flat - however I do not have kids and usually only have 2 to 3 people in the car at one time. Overall, I would buy this car again in a heartbeat.<br> PS: Mazda, please bring the heated steering wheel to U.S versions. We like our hands to be warm too.";
}

function openNav() {
  document.getElementById("sideNavigation").style.width = "230px";
  document.body.style.backgroundColor = "grey";
  document.getElementById("homeCenter").style.opacity = "50%";
}

function closeNav() {
  document.getElementById("sideNavigation").style.width = "0";
  document.body.style.backgroundColor = "white";
  document.getElementById("homeCenter").style.opacity = "100%";
}