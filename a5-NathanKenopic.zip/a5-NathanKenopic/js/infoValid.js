/****************************************************************************
* Assignment5
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually or electronically from any othersource * (including web sites) or distributed to other students.
* Name: Nathan Kenopic  StudentID: 100083203  Date: April 9th, 2021
****************************************************************************/

var error = "";
var firstNameError = "";
var lastNameError = "";
var passwordError = "";
var passwordConError = "";
var usernameError = "";
var ageError = "";

function fullFormCheck() {
    var valid = false;

    firstNameCheck();

    document.getElementById("submitError").innerHTML = firstNameError;

    lastNameCheck();

    document.getElementById("submitError").innerHTML = lastNameError;

    passwordCheck();

    document.getElementById("submitError").innerHTML = passwordError;

    passwordMatch();

    document.getElementById("submitError").innerHTML = passwordConError;

    usernameCheck();

    document.getElementById("submitError").innerHTML = usernameError;

    ageCheck();

    document.getElementById("submitError").innerHTML = ageError;

    if (error == "" && firstNameError == "" && lastNameError == "" && passwordError == "" && usernameError == "" && ageError == "") {
        valid = true;
        document.getElementById("submit").disabled = false;
    }

    return valid;
}

function clearAllErrors() {
    error = "";
    firstNameError = "";
    lastNameError = "";
    passwordError = "";
    usernameError = "";
    ageError = "";

    document.getElementById("firstNameError").innerHTML = firstNameError;
    document.getElementById("lastNameError").innerHTML = lastNameError;
    document.getElementById("passwordError").innerHTML = passwordError;
    document.getElementById("usernameError").innerHTML = usernameError;
    document.getElementById("phoneError").innerHTML = error;
    document.getElementById("ageError").innerHTML = ageError;

    document.getElementById("submit").disabled = false;
}

function firstNameCheck() {
    firstNameError = "";
    var correctNameFormat = /^[A-Z][a-z]*[^0-9][^0-9]*$/;
    var usersFirstName = document.getElementById("firstname").value;

    if (correctNameFormat.test(usersFirstName) == false) {
        firstNameError ="Invalid First Name - Please Enter Correct First Name (Must start with caps and only alphabetical)";
        document.getElementById("submit").disabled = true;
    } else {
        document.getElementById("submit").disabled = false;
    }

    document.getElementById("firstNameError").innerHTML = firstNameError;
}

function lastNameCheck() {
    lastNameError = "";
    var correctNameFormat = /^[A-Z][a-z]*[^0-9][^0-9]*$/;
    var usersLastName = document.getElementById("lastname").value;

    if (correctNameFormat.test(usersLastName) == false) {
        lastNameError ="Invalid Last Name - Please Enter Correct Last Name (Must start with caps and only alphabetical)";
        document.getElementById("submit").disabled = true;
    } else {
        document.getElementById("submit").disabled = false;
    }

    document.getElementById("lastNameError").innerHTML = lastNameError;
}

function passwordCheck() {
    passwordError = "";
    //var correctPass = /^[A-Za-z][A-Za-z0-9]*[A-Z][A-Za-z0-9]*[0-9][A-Za-z0-9]*[A-Za-z0-9]*/;
    var correctPass = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
    var usersPass = document.getElementById("password").value;

    if (correctPass.test(usersPass) == false) {
        passwordError = "Invalid Password - Please Enter Correct Password Format (Starts with a character, needs 1 digit, 1 uppercase, min 6 characters long)";
        document.getElementById("submit").disabled = true;
    } else {
        document.getElementById("submit").disabled = false;
    }

    document.getElementById("passwordError").innerHTML = passwordError;
}

function passwordMatch() {
    passwordConError = "";
    var usersPass = document.getElementById("password").value;
    var usersPassCon = document.getElementById("passwordCon").value;

    if (usersPass != usersPassCon) {
        passwordConError = "Passwords Do Not Match - Please Enter Correct Password";
        document.getElementById("submit").disabled = true;
    } else {
        document.getElementById("submit").disabled = false;
    }

    document.getElementById("passwordMatchError").innerHTML = passwordConError;
}

function usernameCheck() {
    usernameError = "";
    var correctUserFormat = /^[aA-zZ]{6}/;
    var userName = document.getElementById("username").value;

    if (correctUserFormat.test(userName) == false) {
        usernameError = "Invalid Username - Please Enter Correct Username (Must start with a letter and have a minimum of 6)";
        document.getElementById("submit").disabled = true;
    } else {
        document.getElementById("submit").disabled = false;
    }

    document.getElementById("usernameError").innerHTML = usernameError;
}

function phoneNumCheck() {
    error = "";
    var correctPhoneNum = /^([0-9]{3}[-]){2}[0-9]{4}$/;
    var userPhoneNum = document.getElementById("phonenumber").value;

    if (correctPhoneNum.test(userPhoneNum) == false) {
        error = "Invalid Phone Number - Please Enter Correct Phone Number (999-999-9999)";
    }

    document.getElementById("phoneError").innerHTML = error;
}

function ageCheck() {
    ageError = "";
    var usersAge = document.getElementById("age").value;

    if(usersAge < 18 || usersAge > 60) {
        ageError = "Invalid Age - Age Must Be Between 18 and 60";
        document.getElementById("submit").disabled = true;
    } else {
        document.getElementById("submit").disabled = false;
    }

    document.getElementById("ageError").innerHTML = ageError;
}